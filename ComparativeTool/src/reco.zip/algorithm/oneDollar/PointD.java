package algorithm.oneDollar;
import java.awt.Point;

public class PointD extends Point{


}
